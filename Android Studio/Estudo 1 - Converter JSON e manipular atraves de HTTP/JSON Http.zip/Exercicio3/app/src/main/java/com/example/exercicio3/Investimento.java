package com.example.exercicio3;

public class Investimento {
    public double investimentoInicial;
    public int periodoInvestimento;
    public double taxaJuros;
}
